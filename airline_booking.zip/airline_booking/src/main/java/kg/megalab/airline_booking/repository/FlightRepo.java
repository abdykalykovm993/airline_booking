package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.Flight;
import kg.megalab.airline_booking.models.dtos.FlightDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FlightRepo extends JpaRepository<Flight, Long> {

    @Query("select new kg.megalab.airline_booking.models.dtos.FlightDto(u.id, u.airline.id, u.aircraft.id, u.fromAirport.id, u.toAirport.id, u.flightNumber, u.departureTime, u.arrivalTime, u.durationMinutes, u.status) from Flight u")
    List<FlightDto> findAllByIds(int page);
}
