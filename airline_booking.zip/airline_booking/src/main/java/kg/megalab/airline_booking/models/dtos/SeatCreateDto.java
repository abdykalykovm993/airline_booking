package kg.megalab.airline_booking.models.dtos;

import kg.megalab.airline_booking.enums.SeatClass;
import kg.megalab.airline_booking.enums.SeatStatus;

public record SeatCreateDto(
        String seatNumber,
        SeatClass seatClass,
        Long flightId,
        Long aircraftId,
        SeatStatus status

        ) {
}
