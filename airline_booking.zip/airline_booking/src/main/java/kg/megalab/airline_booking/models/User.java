package kg.megalab.airline_booking.models;

import jakarta.persistence.*;
import kg.megalab.airline_booking.enums.Role;

import java.util.List;

/**
 * Пользователь системы — может бронировать билеты, иметь роли.
 */
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Уникальный ID пользователя

    @Column(nullable = false, length = 50)
    private String firstName;  // Имя

    @Column(nullable = false, length = 50)
    private String lastName;  // Фамилия

    @Column(nullable = false, unique = true, length = 100)
    private String email;  // Уникальный email — логин

    @Column(nullable = false)
    private String password;  // Хешированный пароль
    @ElementCollection(fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "role")
    private List<Role> roles;  // Набор ролей пользователя (админ, пользователь и т.д.)

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    // Геттеры и сеттеры
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

}
