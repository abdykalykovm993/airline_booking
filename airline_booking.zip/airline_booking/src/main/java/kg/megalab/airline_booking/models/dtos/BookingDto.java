package kg.megalab.airline_booking.models.dtos;

import java.time.LocalDateTime;

public record BookingDto(
        Long id,
        Long userId,
        Long flightId,
        Long seatId,
        LocalDateTime bookingTime,
        boolean confirmed
) {}
