package kg.megalab.airline_booking.models;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * Сегмент рейса — используется для пересадок
 */
@Entity
@Table(name = "flight_segments")
public class FlightSegment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @JoinColumn
    @ManyToOne(optional = false)
    private Flight flight; // К какому рейсу относится сегмент
    @JoinColumn
    @ManyToOne(optional = false)
    private Airport departure; // Аэропорт вылета сегмента
    @JoinColumn
    @ManyToOne(optional = false)
    private Airport arrival; // Аэропорт прилета сегмента

    private LocalDateTime departureTime; // Время вылета сегмента

    private LocalDateTime arrivalTime; // Время прибытия сегмента

    private int segmentOrder; // Порядок сегмента (если несколько)

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Airport getDeparture() {
        return departure;
    }

    public void setDeparture(Airport departure) {
        this.departure = departure;
    }

    public Airport getArrival() {
        return arrival;
    }

    public void setArrival(Airport arrival) {
        this.arrival = arrival;
    }

    public LocalDateTime getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(LocalDateTime departureTime) {
        this.departureTime = departureTime;
    }

    public LocalDateTime getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(LocalDateTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getSegmentOrder() {
        return segmentOrder;
    }

    public void setSegmentOrder(int segmentOrder) {
        this.segmentOrder = segmentOrder;
    }
}
