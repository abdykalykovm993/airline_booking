package kg.megalab.airline_booking.services;


import kg.megalab.airline_booking.models.dtos.PaymentCreateDto;
import kg.megalab.airline_booking.models.dtos.PaymentDto;

import java.util.List;

public interface PaymentService {

    PaymentDto create(PaymentCreateDto paymentCreateDto);

    PaymentDto update(PaymentDto paymentDto);

    PaymentDto delete(Long id);

    List<PaymentDto> findAlByIds(int page, int size);

    PaymentDto findById(Long id);
}
