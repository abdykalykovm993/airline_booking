package kg.megalab.airline_booking.services;


import kg.megalab.airline_booking.models.dtos.UserCreateDto;
import kg.megalab.airline_booking.models.dtos.UserDto;

import java.util.List;

public interface UserService {


    UserDto create(UserCreateDto userCreateDto);

    UserDto update(UserDto userDto);

    UserDto delete(Long id);

    List<UserDto> findAllByIds(int page, int size);

    UserDto findById(Long id);
}
