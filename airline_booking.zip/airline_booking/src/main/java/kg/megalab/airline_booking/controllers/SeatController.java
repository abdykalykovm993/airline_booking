package kg.megalab.airline_booking.controllers;

import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.SeatCreateDto;
import kg.megalab.airline_booking.models.dtos.SeatDto;
import kg.megalab.airline_booking.services.SeatService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/Seat")
public class SeatController implements CRUDController<SeatDto, SeatCreateDto> {

    private final SeatService seatService;

    public SeatController(SeatService seatService) {
        this.seatService = seatService;
    }
    @PostMapping("/create")

    @Override
    public ResponseEntity<SeatDto> create(SeatCreateDto seatCreateDto) {
        SeatDto seatDto = seatService.create(seatCreateDto);
        return ResponseEntity.created(null).body(seatDto);
    }
    @PutMapping("/update")

    @Override
    public ResponseEntity<SeatDto> update(SeatDto seatDto) {
        SeatDto seatDtoUpdate= seatService.update(seatDto);
        return ResponseEntity.ok(seatDtoUpdate);
    }
    @DeleteMapping("/delete/{id}")

    @Override
    public ResponseEntity<SeatDto> delete(Long id) {
        SeatDto seatDto = seatService.delete(id);
        return ResponseEntity.ok(seatDto);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<SeatDto>> allList(int page, int size) {
        List<SeatDto> seatDtos =seatService.findAllByIds(page, size);
        return new ResponseEntity<>(seatDtos, HttpStatus.OK);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<SeatDto> findById(Long id) {
        SeatDto seatDto = seatService.findById(id);
        return ResponseEntity.ok(seatDto);
    }
}
