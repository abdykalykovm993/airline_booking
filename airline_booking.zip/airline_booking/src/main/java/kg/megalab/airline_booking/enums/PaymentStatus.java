package kg.megalab.airline_booking.enums;

public enum PaymentStatus {
    PAID,
    FAILED,
    REFUNDED
}
