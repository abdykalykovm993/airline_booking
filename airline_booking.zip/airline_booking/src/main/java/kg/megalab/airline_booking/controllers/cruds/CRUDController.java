package kg.megalab.airline_booking.controllers.cruds;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

public interface CRUDController<Dto, CreateDto> {

    @PostMapping("/create")
    ResponseEntity<Dto> create(@Valid @RequestBody CreateDto dto);

    @PutMapping("/update/{id}")
    ResponseEntity<Dto> update(@Valid @RequestBody Dto dto);

    @DeleteMapping("/delete/{id}")

    ResponseEntity<Dto> delete(@PathVariable("id") Long id);
    @GetMapping("/list")

    ResponseEntity<List<Dto>> allList(
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size);

    @GetMapping("/{id}")
    ResponseEntity<Dto> findById(@PathVariable("id") Long id);
}

