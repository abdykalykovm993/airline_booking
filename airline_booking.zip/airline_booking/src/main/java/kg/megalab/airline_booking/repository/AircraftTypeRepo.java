package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.AircraftType;
import kg.megalab.airline_booking.models.dtos.AircraftTypeDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AircraftTypeRepo extends JpaRepository<AircraftType, Long> {

    @Query("select new kg.megalab.airline_booking.models.dtos.AircraftTypeDto(u.id, u.model, u.manufacturer, u.iataCode) from AircraftType u")
    List<AircraftTypeDto> findAllByIds(Pageable pageable);
}
