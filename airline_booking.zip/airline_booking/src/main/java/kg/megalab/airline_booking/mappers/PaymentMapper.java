package kg.megalab.airline_booking.mappers;

import kg.megalab.airline_booking.models.Payment;
import kg.megalab.airline_booking.models.dtos.PaymentCreateDto;
import kg.megalab.airline_booking.models.dtos.PaymentDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PaymentMapper {
    PaymentMapper INSTANCE = Mappers.getMapper(PaymentMapper.class);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "paymentTime", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(source = "bookingId", target = "booking.id")
    Payment toEntity(PaymentCreateDto paymentCreateDto);

    @Mapping(target = "paymentTime", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(source = "booking", target = "booking.id")
    Payment toEntity(PaymentDto paymentDto);

    @Mapping(source = "booking.id", target = "booking")
    PaymentDto toDto(Payment payment);
}
