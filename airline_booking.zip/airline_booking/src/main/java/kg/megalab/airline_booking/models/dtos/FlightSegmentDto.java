
package kg.megalab.airline_booking.models.dtos;

import java.time.LocalDateTime;

public record FlightSegmentDto(
        Long id,
        Long flightId,
        Long departureAirportId,
        Long arrivalAirportId,
        LocalDateTime departureTime,
        LocalDateTime arrivalTime,
        int segmentOrder

) {
}