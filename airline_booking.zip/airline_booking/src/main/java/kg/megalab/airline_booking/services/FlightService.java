package kg.megalab.airline_booking.services;


import kg.megalab.airline_booking.models.dtos.FlightCreateDto;
import kg.megalab.airline_booking.models.dtos.FlightDto;

import java.util.List;

public interface FlightService {
    FlightDto create(FlightCreateDto flightCreateDto);

    FlightDto update(FlightDto flightDto);

    FlightDto delete(Long id);

    List<FlightDto> findAllByIds(int page, int size);

    FlightDto findById(Long id);
}
