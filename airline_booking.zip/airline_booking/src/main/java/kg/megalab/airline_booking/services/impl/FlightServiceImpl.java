package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;
import kg.megalab.airline_booking.mappers.FlightMapper;
import kg.megalab.airline_booking.models.Flight;
import kg.megalab.airline_booking.models.dtos.FlightCreateDto;
import kg.megalab.airline_booking.models.dtos.FlightDto;
import kg.megalab.airline_booking.repository.FlightRepo;
import kg.megalab.airline_booking.services.FlightService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Transactional

public class FlightServiceImpl implements FlightService {

    private final FlightRepo flightRepo;

    public FlightServiceImpl(FlightRepo flightRepo) {
        this.flightRepo = flightRepo;
    }

    @Override
    public FlightDto create(FlightCreateDto flightCreateDto) {
        Flight flight = FlightMapper.INSTANCE.toEntity(flightCreateDto);
        return FlightMapper.INSTANCE.toDto(flightRepo.save(flight));
    }

    @Override
    public FlightDto update(FlightDto flightDto) {
        Flight flight = FlightMapper.INSTANCE.toEntity(flightDto);
        return FlightMapper.INSTANCE.toDto(flightRepo.save(flight));
    }

    @Override
    public FlightDto delete(Long id) {
        Flight flight = flightRepo.findById(id).orElseThrow(()-> new RuntimeException("Flight not found"));
        flightRepo.delete(flight);
        return FlightMapper.INSTANCE.toDto(flight);
    }

    @Override
    public List<FlightDto> findAllByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return flightRepo.findAllByIds(page);
    }

    @Override
    public FlightDto findById(Long id) {
        Flight flight = flightRepo.findById(id).orElseThrow(()-> new RuntimeException("Flight not found"));
        return FlightMapper.INSTANCE.toDto(flight);
    }
}
