package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.Aircraft;
import kg.megalab.airline_booking.models.dtos.AircraftDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AircraftRepo extends JpaRepository<Aircraft, Long> {

    @Query("select new kg.megalab.airline_booking.models.dtos.AircraftDto(u.id, u.airline.id, u.type.id, u.registrationNumber) from Aircraft u")
    List<AircraftDto> findAllByIds(Pageable pageable);
}
