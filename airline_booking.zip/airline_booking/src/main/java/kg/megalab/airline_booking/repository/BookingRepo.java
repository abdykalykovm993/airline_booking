package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.Booking;
import kg.megalab.airline_booking.models.dtos.BookingDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepo extends JpaRepository<Booking, Long> {
    @Query("select new kg.megalab.airline_booking.models.dtos.BookingDto(u.id, u.user.id, u.flight.id, u.seat.id, u.bookingTime, u.confirmed) from Booking u")
    Page<BookingDto> findAllByIds(Pageable pageable);
}
