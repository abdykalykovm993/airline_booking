package kg.megalab.airline_booking.mappers;

import kg.megalab.airline_booking.models.Airline;
import kg.megalab.airline_booking.models.dtos.AirlineCreateDto;
import kg.megalab.airline_booking.models.dtos.AirlineDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AirlineMapper {
    AirlineMapper INSTANCE = Mappers.getMapper(AirlineMapper.class);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "aircraftList", ignore = true)
    Airline toEntity(AirlineCreateDto airlineCreateDto);

    AirlineDto toDto(Airline airline);

    @Mapping(target = "aircraftList", ignore = true)
    Airline toEntity(AirlineDto airlineDto);
}
