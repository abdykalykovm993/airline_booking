package kg.megalab.airline_booking.models.dtos;

import kg.megalab.airline_booking.enums.Role;

import java.util.List;

public record UserCreateDto(
        String firstName,
        String lastName,
        String email,
        String password,
        List<Role> roles
) {
}
