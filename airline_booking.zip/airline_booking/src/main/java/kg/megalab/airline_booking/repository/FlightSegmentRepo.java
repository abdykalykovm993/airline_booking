package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.FlightSegment;
import kg.megalab.airline_booking.models.dtos.FlightSegmentDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FlightSegmentRepo extends JpaRepository<FlightSegment, Long> {
    @Query("select new kg.megalab.airline_booking.models.dtos.FlightSegmentDto(u.id, u.arrival.id, u.flight.id, u.departure.id, u.arrivalTime, u.departureTime, u.segmentOrder) from FlightSegment u")
    List<FlightSegmentDto> findAllByIds(Pageable pageable);
}
