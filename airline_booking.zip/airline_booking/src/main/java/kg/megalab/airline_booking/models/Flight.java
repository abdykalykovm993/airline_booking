package kg.megalab.airline_booking.models;

import jakarta.persistence.*;
import kg.megalab.airline_booking.enums.FlightStatus;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Рейс — конкретный перелет с A в B
 */
@Entity
@Table(name = "flights")
public class Flight {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 20)
    private String flightNumber; // Номер рейса (например: "TK245")
    @JoinColumn
    @ManyToOne(optional = false)
    private Airline airline; // Какая авиакомпания выполняет рейс
    @JoinColumn
    @ManyToOne(optional = false)
    private Aircraft aircraft; // Какой самолет выполняет рейс
    @JoinColumn
    @ManyToOne(optional = false)
    private Airport fromAirport; // Аэропорт вылета
    @JoinColumn
    @ManyToOne(optional = false)
    private Airport toAirport; // Аэропорт прилета

    @Column(nullable = false)
    private LocalDateTime departureTime; // Время вылета

    @Column(nullable = false)
    private LocalDateTime arrivalTime; // Время прибытия

    @Column(nullable = false)
    private int durationMinutes; // Длительность полета в минутах

    @Enumerated(EnumType.STRING)
    private FlightStatus status; // Статус рейса (SCHEDULED, CANCELLED и т.д.)
    @OneToMany(mappedBy = "flight", cascade = CascadeType.ALL)
    private List<FlightSegment> segments; // Сегменты (для пересадок и сложных маршрутов)

    @OneToMany(mappedBy = "flight", cascade = CascadeType.ALL)
    private List<Seat> seats; // Список мест на борту (можно связать с бронированием)

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public Airline getAirline() {
        return airline;
    }

    public void setAirline(Airline airline) {
        this.airline = airline;
    }

    public Aircraft getAircraft() {
        return aircraft;
    }

    public void setAircraft(Aircraft aircraft) {
        this.aircraft = aircraft;
    }

    public Airport getFromAirport() {
        return fromAirport;
    }

    public void setFromAirport(Airport fromAirport) {
        this.fromAirport = fromAirport;
    }

    public Airport getToAirport() {
        return toAirport;
    }

    public void setToAirport(Airport toAirport) {
        this.toAirport = toAirport;
    }

    public LocalDateTime getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(LocalDateTime departureTime) {
        this.departureTime = departureTime;
    }

    public LocalDateTime getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(LocalDateTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public FlightStatus getStatus() {
        return status;
    }

    public void setStatus(FlightStatus status) {
        this.status = status;
    }

    public List<FlightSegment> getSegments() {
        return segments;
    }

    public void setSegments(List<FlightSegment> segments) {
        this.segments = segments;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    public void setSeats(List<Seat> seats) {
        this.seats = seats;
    }
}
