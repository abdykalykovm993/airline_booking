package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.Airline;
import kg.megalab.airline_booking.models.dtos.AirlineDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AirlineRepo extends JpaRepository<Airline, Long> {

    @Query(" select new kg.megalab.airline_booking.models.dtos.AirlineDto( u.id, u.name, u.iataCode, u.icaoCode, u.country, u.city ) from Airline u " )
    List<AirlineDto> findAllByIds(Pageable pageable);
}
