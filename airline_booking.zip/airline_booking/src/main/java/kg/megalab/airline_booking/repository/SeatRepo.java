package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.Seat;
import kg.megalab.airline_booking.models.dtos.SeatDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SeatRepo extends JpaRepository<Seat, Long> {

    @Query("select new kg.megalab.airline_booking.models.dtos.SeatDto(u.id, u.flight.id, u.aircraft.id, u.seatNumber, u.seatClass, u.status) from Seat u")
    List<SeatDto> findAllByIds(Pageable pageable);
}
