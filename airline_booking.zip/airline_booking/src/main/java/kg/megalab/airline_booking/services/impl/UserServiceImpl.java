package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;
import kg.megalab.airline_booking.mappers.UserMapper;
import kg.megalab.airline_booking.models.User;
import kg.megalab.airline_booking.models.dtos.UserCreateDto;
import kg.megalab.airline_booking.models.dtos.UserDto;
import kg.megalab.airline_booking.repository.UserRepo;
import kg.megalab.airline_booking.services.UserService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService {
    private final UserRepo userRepo;

    public UserServiceImpl(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    @Override
    public UserDto create(UserCreateDto userCreateDto) {
        User user = UserMapper.INSTANCE.toEntity(userCreateDto);

        return UserMapper.INSTANCE.toDto(userRepo.save(user));
    }

    @Override
    public UserDto update(UserDto userDto) {
        User user = UserMapper.INSTANCE.toEntity(userDto);
        return UserMapper.INSTANCE.toDto(userRepo.save(user));
    }

    @Override
    public UserDto delete(Long id) {
        User user = userRepo.findById(id).orElseThrow(()-> new RuntimeException("User not found"));
        userRepo.delete(user);
        return UserMapper.INSTANCE.toDto(user);
    }

    @Override
    public List<UserDto> findAllByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return userRepo.findAll(pageable).stream()
                .map(UserMapper.INSTANCE::toDto)
                .toList();
    }

    @Override
    public UserDto findById(Long id) {
        User user = userRepo.findById(id).orElseThrow(()-> new RuntimeException("User not found"));
        return UserMapper.INSTANCE.toDto(user);
    }

}
