package kg.megalab.airline_booking.controllers;

import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.AircraftTypeCreateDto;
import kg.megalab.airline_booking.models.dtos.AircraftTypeDto;
import kg.megalab.airline_booking.services.AircraftTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/AircrafType")
public class AircraftTypeController implements CRUDController<AircraftTypeDto, AircraftTypeCreateDto> {

    private final AircraftTypeService aircraftTypeService;

    public AircraftTypeController(AircraftTypeService aircraftTypeService) {
        this.aircraftTypeService = aircraftTypeService;
    }
    @PostMapping("/create")

    @Override
    public ResponseEntity<AircraftTypeDto> create(AircraftTypeCreateDto aircraftTypeCreateDto) {
        AircraftTypeDto aircraftTypeDto =aircraftTypeService.create(aircraftTypeCreateDto);
        return ResponseEntity.created(null).body(aircraftTypeDto);
    }
    @PutMapping("/update")

    @Override
    public ResponseEntity<AircraftTypeDto> update(AircraftTypeDto aircraftTypeDto) {
        AircraftTypeDto aircraftTypeDtoUpdate =aircraftTypeService.update(aircraftTypeDto);
        return ResponseEntity.ok(aircraftTypeDtoUpdate);
    }
    @DeleteMapping("/delete/{id}")

    @Override
    public ResponseEntity<AircraftTypeDto> delete(Long id) {
        AircraftTypeDto aircraftTypeDto = aircraftTypeService.delete(id);
        return ResponseEntity.ok(aircraftTypeDto);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<AircraftTypeDto>> allList(int page, int size) {
        List<AircraftTypeDto> aircraftTypeDtos  = aircraftTypeService.findAllByIds(page, size);
        return new ResponseEntity<>(aircraftTypeDtos, HttpStatus.OK);
    }
    @GetMapping ("/get/{id}")

    @Override
    public ResponseEntity<AircraftTypeDto> findById(Long id) {
        AircraftTypeDto aircraftTypeDto = aircraftTypeService.findByIdDto(id);
        return ResponseEntity.ok(aircraftTypeDto);
    }
}