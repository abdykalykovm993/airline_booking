package kg.megalab.airline_booking.services;


import kg.megalab.airline_booking.models.Airline;
import kg.megalab.airline_booking.models.dtos.AirlineCreateDto;
import kg.megalab.airline_booking.models.dtos.AirlineDto;

import java.util.List;

public interface AirlineService {


    AirlineDto create(AirlineCreateDto airlineCreateDto);

    AirlineDto update(AirlineDto airlineDto);

    AirlineDto delete(Long id);

    List<AirlineDto> findAllByIds(int page, int size);

    AirlineDto findByIdDto(Long id);


    Airline findById(Long aLong);
}
