package kg.megalab.airline_booking.services;


import kg.megalab.airline_booking.models.dtos.FlightSegmentCreateDto;
import kg.megalab.airline_booking.models.dtos.FlightSegmentDto;

import java.util.List;

public interface FlightSegmentService {
    
    FlightSegmentDto create(FlightSegmentCreateDto flightSegmentCreateDto);

    FlightSegmentDto update(FlightSegmentDto flightSegmentDto);

    FlightSegmentDto delete(Long id);

    List<FlightSegmentDto> findAllByIds(int page, int size);

    FlightSegmentDto findById(Long id);
}
