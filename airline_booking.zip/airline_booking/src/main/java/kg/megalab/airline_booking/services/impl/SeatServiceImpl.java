package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;
import kg.megalab.airline_booking.mappers.SeatMapper;
import kg.megalab.airline_booking.models.Seat;
import kg.megalab.airline_booking.models.dtos.SeatCreateDto;
import kg.megalab.airline_booking.models.dtos.SeatDto;
import kg.megalab.airline_booking.repository.SeatRepo;
import kg.megalab.airline_booking.services.SeatService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional

public class SeatServiceImpl implements SeatService {

    private final SeatRepo seatRepo;

    public SeatServiceImpl(SeatRepo seatRepo) {
        this.seatRepo = seatRepo;
    }

    @Override
    public SeatDto create(SeatCreateDto seatCreateDto) {
        Seat seat = SeatMapper.INSTANCE.toEntity(seatCreateDto);
        return SeatMapper.INSTANCE.toDto(seatRepo.save(seat));
    }

    @Override
    public SeatDto update(SeatDto seatDto) {
        Seat seat = SeatMapper.INSTANCE.toEntity(seatDto);
        return SeatMapper.INSTANCE.toDto(seatRepo.save(seat));
    }

    @Override
    public SeatDto delete(Long id) {
        Seat seat = seatRepo.findById(id).orElseThrow(()-> new RuntimeException("Seat does not exist"));
        seatRepo.delete(seat);
        return SeatMapper.INSTANCE.toDto(seat);
    }

    @Override
    public List<SeatDto> findAllByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size );
        return seatRepo.findAllByIds(pageable);
    }

    @Override
    public SeatDto findById(Long id) {
        Seat seat = seatRepo.findById(id).orElseThrow(()-> new RuntimeException("Seat does not exist"));
        return SeatMapper.INSTANCE.toDto(seat);
    }
}
