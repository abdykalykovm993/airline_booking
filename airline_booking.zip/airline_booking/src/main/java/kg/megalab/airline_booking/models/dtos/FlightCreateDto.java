package kg.megalab.airline_booking.models.dtos;

import kg.megalab.airline_booking.enums.FlightStatus;

import java.time.LocalDateTime;
import java.util.List;

public record FlightCreateDto(
        String flightNumber,
        Long airlineId,
        Long aircraftId,
        Long fromAirportId,
        Long toAirportId,
        LocalDateTime departureTime,
        LocalDateTime arrivalTime,
        int durationMinutes

) {
}
