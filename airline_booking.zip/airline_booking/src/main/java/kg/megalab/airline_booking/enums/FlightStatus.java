package kg.megalab.airline_booking.enums;

public enum FlightStatus {
    SCHEDULED,  // Запланирован
    DELAYED,    // Задержан
    CANCELLED,  // Отменён
    COMPLETED,  // Завершён
    IN_AIR,     // В воздухе
    ARRIVED     // Прибыл в пункт назначения
}
