package kg.megalab.airline_booking.enums;

public enum Role {
    USER,
    ADMIN,
    MANAGER
}
