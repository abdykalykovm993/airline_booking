package kg.megalab.airline_booking.models;

import jakarta.persistence.*;
import jdk.jfr.Enabled;
import kg.megalab.airline_booking.enums.PaymentStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
/**
 * Оплата брони
 */
@Entity
@Table(name = "payments")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JoinColumn
    @OneToOne(optional = false)
    private Booking booking; // К какому бронированию относится платеж

    private double amount; // Сумма оплаты

    private String method; // Метод оплаты (например: карта)

    private LocalDateTime paymentTime; // Время оплаты

    @Enumerated(EnumType.STRING)
    private PaymentStatus status; // Статус: оплачено, неудача и т.д.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public LocalDateTime getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(LocalDateTime paymentTime) {
        this.paymentTime = paymentTime;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public void setStatus(PaymentStatus status) {
        this.status = status;
    }
}

