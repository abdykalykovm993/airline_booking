package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;
import kg.megalab.airline_booking.mappers.AircraftMapper;
import kg.megalab.airline_booking.models.Aircraft;
import kg.megalab.airline_booking.models.AircraftType;
import kg.megalab.airline_booking.models.Airline;
import kg.megalab.airline_booking.models.dtos.AircraftCreateDto;
import kg.megalab.airline_booking.models.dtos.AircraftDto;
import kg.megalab.airline_booking.repository.AircraftRepo;
import kg.megalab.airline_booking.services.AircraftService;
import kg.megalab.airline_booking.services.AircraftTypeService;
import kg.megalab.airline_booking.services.AirlineService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Transactional
public class AircraftServiceImpl implements AircraftService {

    private final AircraftRepo aircraftRepo;
    private final AircraftTypeService aircraftTypeService;
    private final AirlineService airlineService;

    public AircraftServiceImpl(AircraftRepo aircraftRepo, AircraftTypeService aircraftTypeService, AirlineService airlineService) {
        this.aircraftRepo = aircraftRepo;
        this.aircraftTypeService = aircraftTypeService;
        this.airlineService = airlineService;
    }

//    @Override
//    public AircraftDto create(AircraftCreateDto aircraftCreateDto) {
//        AircraftType aircraftType = aircraftTypeService.findById(aircraftCreateDto.aircraftTypeId());
//        Airline airline = airlineService.findById(aircraftCreateDto.airlineId());
//        Aircraft aircraft = AircraftMapper.INSTANCE.toEntity(aircraftCreateDto, airline, aircraftType);
//        return AircraftMapper.INSTANCE.toDto(aircraftRepo.save(aircraft));
//    }
//
//    @Override
//    public AircraftDto update(AircraftDto aircraftDto) {
//        AircraftType aircraftType = aircraftTypeService.findById(aircraftDto.aircraftTypeId());
//        Airline airline = airlineService.findById(aircraftDto.airlineId());
//        Aircraft aircraft = AircraftMapper.INSTANCE.toEntity(aircraftDto, airline, aircraftType);
//        return AircraftMapper.INSTANCE.toDto(aircraftRepo.save(aircraft));
//    }

    @Override
    public AircraftDto create(AircraftCreateDto aircraftCreateDto) {
        return null;
    }

    @Override
    public AircraftDto update(AircraftDto aircraftDto) {
        return null;
    }

    @Override
    public AircraftDto delete(Long id) {
        Aircraft aircraft= aircraftRepo.findById(id).orElseThrow(()->new RuntimeException("Aircraft not found"));
        aircraftRepo.delete(aircraft);
        return AircraftMapper.INSTANCE.toDto(aircraft);
    }

    @Override
    public List<AircraftDto> findAllByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return aircraftRepo.findAllByIds(pageable);
    }

    @Override
    public AircraftDto findById(Long id) {
        Aircraft aircraft = aircraftRepo.findById(id).orElseThrow(()-> new RuntimeException("нет такого "));
        return AircraftMapper.INSTANCE.toDto(aircraft);
    }
}
