package kg.megalab.airline_booking.models.dtos;

import kg.megalab.airline_booking.enums.Role;

import java.util.List;

public record UserDto(
        Long id,
        String firstName,
        String lastName,
        String password,
        String email,
        List<Role> roles
        ) {
}
