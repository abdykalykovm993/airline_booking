package kg.megalab.airline_booking.mappers;

import kg.megalab.airline_booking.models.FlightSegment;
import kg.megalab.airline_booking.models.dtos.FlightSegmentCreateDto;
import kg.megalab.airline_booking.models.dtos.FlightSegmentDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface FlightSegmentMapper {
    FlightSegmentMapper INSTANCE = Mappers.getMapper(FlightSegmentMapper.class);

    @Mapping(source = "flightId", target = "flight")
    @Mapping(source = "departureAirportId", target = "departure")
    @Mapping(source = "arrivalAirportId", target = "arrival")
    @Mapping(target = "id", ignore = true)
    FlightSegment toEntity(FlightSegmentCreateDto dto);

    @Mapping(source = "flightId", target = "flight")
    @Mapping(source = "departureAirportId", target = "departure")
    @Mapping(source = "arrivalAirportId", target = "arrival")
    FlightSegment toEntity(FlightSegmentDto dto);

    @Mapping(source = "flight.id", target = "flightId")
    @Mapping(source = "departure.id", target = "departureAirportId")
    @Mapping(source = "arrival.id", target = "arrivalAirportId")
    FlightSegmentDto toDto(FlightSegment entity);

    default kg.megalab.airline_booking.models.Flight map(Long id) {
        if (id == null) return null;
        var flight = new kg.megalab.airline_booking.models.Flight();
        flight.setId(id);
        return flight;
    }

    default Long map(kg.megalab.airline_booking.models.Flight flight) {
        return flight != null ? flight.getId() : null;
    }

    default kg.megalab.airline_booking.models.Airport mapAirport(Long id) {
        if (id == null) return null;
        var airport = new kg.megalab.airline_booking.models.Airport();
        airport.setId(id);
        return airport;
    }

    default Long mapAirport(kg.megalab.airline_booking.models.Airport airport) {
        return airport != null ? airport.getId() : null;
    }
}
