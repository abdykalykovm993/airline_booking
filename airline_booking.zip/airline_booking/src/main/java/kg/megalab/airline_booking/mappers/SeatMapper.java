package kg.megalab.airline_booking.mappers;

import kg.megalab.airline_booking.models.Seat;
import kg.megalab.airline_booking.models.dtos.SeatCreateDto;
import kg.megalab.airline_booking.models.dtos.SeatDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SeatMapper {
    SeatMapper INSTANCE = Mappers.getMapper(SeatMapper.class);
    @Mapping(source = "aircraftId", target = "aircraft.id")
    @Mapping(source = "flightId", target = "flight.id")
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "status", ignore = false)
    Seat toEntity(SeatCreateDto seatCreateDto);

    @Mapping(source = "aircraft.id", target = "aircraftId")
    @Mapping(source = "flight.id", target = "flightId")
    SeatDto toDto(Seat seat);

    @Mapping(source = "aircraftId", target = "aircraft.id")
    @Mapping(source = "flightId", target = "flight.id")
    Seat toEntity(SeatDto seatDto);
}
