package kg.megalab.airline_booking.models;

import jakarta.persistence.*;

import java.util.List;

/**
 * Сущность "Airline" представляет авиакомпанию, которая владеет самолетами и выполняет рейсы.

 Авиакомпания — владелец самолетов и рейсов*/

@Entity
@Table(name = "airlines") // Указываем имя таблицы в БД
public class Airline {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Уникальный идентификатор авиакомпании (первичный ключ)

    @OneToMany(mappedBy = "airline", cascade = CascadeType.ALL)
    private List<Aircraft> aircraftList; // Список самолетов, принадлежащих авиакомпании

    @Column(nullable = false)
    private String name; // Название авиакомпании (например, "Turkish Airlines")

    @Column(nullable = false, length = 2, unique = true)
    private String iataCode; // IATA-код — 2 буквы, например "TK"

    @Column(nullable = false, length = 3, unique = true)
    private String icaoCode; // ICAO-код — 3 буквы, например "THY"

    @Column(nullable = false)
    private String country; // Страна, в которой зарегистрирована авиакомпания

    @Column(nullable = false)
    private String city; // Город головного офиса авиакомпании

    public List<Aircraft> getAircraftList() {
        return aircraftList;
    }

    public void setAircraftList(List<Aircraft> aircraftList) {
        this.aircraftList = aircraftList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIataCode() {
        return iataCode;
    }

    public void setIataCode(String iataCode) {
        this.iataCode = iataCode;
    }

    public String getIcaoCode() {
        return icaoCode;
    }

    public void setIcaoCode(String icaoCode) {
        this.icaoCode = icaoCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
