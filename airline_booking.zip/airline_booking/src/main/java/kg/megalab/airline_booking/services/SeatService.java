package kg.megalab.airline_booking.services;

import kg.megalab.airline_booking.models.dtos.SeatCreateDto;
import kg.megalab.airline_booking.models.dtos.SeatDto;

import java.util.List;

public interface SeatService {
    SeatDto create(SeatCreateDto seatCreateDto);

    SeatDto update(SeatDto seatDto);

    SeatDto delete(Long id);

    List<SeatDto> findAllByIds(int page, int size);

    SeatDto findById(Long id);
}
