package kg.megalab.airline_booking.models.dtos;

public record AirlineDto(
        Long id,
        String name,
        String iataCode,
        String icaoCode,
        String country,
        String city
) {}
