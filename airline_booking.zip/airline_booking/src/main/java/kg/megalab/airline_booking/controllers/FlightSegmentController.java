package kg.megalab.airline_booking.controllers;

import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.FlightSegmentCreateDto;
import kg.megalab.airline_booking.models.dtos.FlightSegmentDto;
import kg.megalab.airline_booking.services.FlightSegmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
@RestController
@RequestMapping("/api/FlightSegment")
public class FlightSegmentController implements CRUDController<FlightSegmentDto, FlightSegmentCreateDto> {

    private final FlightSegmentService flightSegmentService;

    public FlightSegmentController(FlightSegmentService flightSegmentService) {
        this.flightSegmentService = flightSegmentService;
    }
    @PostMapping("/create")

    @Override
    public ResponseEntity<FlightSegmentDto> create(FlightSegmentCreateDto flightSegmentCreateDto) {
        FlightSegmentDto flightSegmentDto = flightSegmentService.create(flightSegmentCreateDto);
        return ResponseEntity.created(null).body(flightSegmentDto);
    }
    @PutMapping("/update")

    @Override
    public ResponseEntity<FlightSegmentDto> update(FlightSegmentDto flightSegmentDto) {
        FlightSegmentDto flightSegmentDtoUpdate = flightSegmentService.update(flightSegmentDto);
        return ResponseEntity.ok(flightSegmentDtoUpdate);
    }
    @DeleteMapping("/delete/{id}")

    @Override
    public ResponseEntity<FlightSegmentDto> delete(Long id) {
        FlightSegmentDto flightSegmentDto = flightSegmentService.delete(id);
        return ResponseEntity.ok(flightSegmentDto);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<FlightSegmentDto>> allList(int page, int size) {
        List<FlightSegmentDto> flightSegmentDtos = flightSegmentService.findAllByIds(page, size);
        return new ResponseEntity<>(flightSegmentDtos, HttpStatus.OK);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<FlightSegmentDto> findById(Long id) {
        FlightSegmentDto flightSegmentDto = flightSegmentService.findById(id);
        return ResponseEntity.ok(flightSegmentDto);
    }

}