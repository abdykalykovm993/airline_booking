package kg.megalab.airline_booking.enums;

public enum SeatClass {
    ECONOMY,
    BUSINESS,
    FIRST
}
