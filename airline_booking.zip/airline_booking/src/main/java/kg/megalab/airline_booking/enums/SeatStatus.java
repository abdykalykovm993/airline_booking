package kg.megalab.airline_booking.enums;

public enum SeatStatus {
    AVAILABLE,
    BOOKED,
    BLOCKED
}
