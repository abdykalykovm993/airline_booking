package kg.megalab.airline_booking.mappers;

import kg.megalab.airline_booking.models.Aircraft;
import kg.megalab.airline_booking.models.Airline;
import kg.megalab.airline_booking.models.Airport;
import kg.megalab.airline_booking.models.Flight;
import kg.megalab.airline_booking.models.dtos.FlightCreateDto;
import kg.megalab.airline_booking.models.dtos.FlightDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface FlightMapper {
    FlightMapper INSTANCE = Mappers.getMapper(FlightMapper.class);
    @Mapping(source = "airlineId", target = "airline")
    @Mapping(source = "aircraftId", target = "aircraft")
    @Mapping(source = "fromAirportId", target = "fromAirport")
    @Mapping(source = "toAirportId", target = "toAirport")
    @Mapping(target = "status", ignore = true) // если не передаёте статус при создании
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "segments", ignore = true)
    @Mapping(target = "seats", ignore = true)
    Flight toEntity(FlightCreateDto dto);

    @Mapping(source = "airline.id", target = "airlineId")
    @Mapping(source = "aircraft.id", target = "aircraftId")
    @Mapping(source = "fromAirport.id", target = "fromAirportId")
    @Mapping(source = "toAirport.id", target = "toAirportId")
    FlightDto toDto(Flight entity);

    @Mapping(source = "airlineId", target = "airline")
    @Mapping(source = "aircraftId", target = "aircraft")
    @Mapping(source = "fromAirportId", target = "fromAirport")
    @Mapping(source = "toAirportId", target = "toAirport")
    Flight toEntity(FlightDto dto);


    default Airline mapAirline(Long id) {
        if (id == null) return null;
        Airline airline = new Airline();
        airline.setId(id);
        return airline;
    }

    default Long mapAirline(Airline airline) {
        return airline != null ? airline.getId() : null;
    }

    default Aircraft mapAircraft(Long id) {
        if (id == null) return null;
        Aircraft aircraft = new Aircraft();
        aircraft.setId(id);
        return aircraft;
    }

    default Long mapAircraft(Aircraft aircraft) {
        return aircraft != null ? aircraft.getId() : null;
    }

    default Airport mapAirport(Long id) {
        if (id == null) return null;
        Airport airport = new Airport();
        airport.setId(id);
        return airport;
    }

    default Long mapAirport(Airport airport) {
        return airport != null ? airport.getId() : null;
    }
}
