package kg.megalab.airline_booking.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Сущность бронирования билета пассажиром на рейс.
 */
@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Уникальный идентификатор бронирования
    @JoinColumn
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private User user;  // Пользователь, который сделал бронирование
    @JoinColumn
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Flight flight;  // Рейс, на который сделано бронирование
    @JoinColumn
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Seat seat;  // Место, которое забронировано

    @Column(nullable = false)
    private LocalDateTime bookingTime;  // Время создания бронирования

    @Column(nullable = false)
    private boolean confirmed;  // Подтверждено ли бронирование (true/false)

    // Геттеры и сеттеры ниже
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Flight getFlight() { return flight; }
    public void setFlight(Flight flight) { this.flight = flight; }

    public Seat getSeat() { return seat; }
    public void setSeat(Seat seat) { this.seat = seat; }

    public LocalDateTime getBookingTime() { return bookingTime; }
    public void setBookingTime(LocalDateTime bookingTime) { this.bookingTime = bookingTime; }

    public boolean isConfirmed() { return confirmed; }
    public void setConfirmed(boolean confirmed) { this.confirmed = confirmed; }
}
