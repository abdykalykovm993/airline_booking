package kg.megalab.airline_booking.controllers;

import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.UserCreateDto;
import kg.megalab.airline_booking.models.dtos.UserDto;
import kg.megalab.airline_booking.services.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/User")
public class UserController implements CRUDController<UserDto, UserCreateDto> {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/create")
    @Override
    public ResponseEntity<UserDto> create(UserCreateDto userCreateDto) {
        UserDto userDto = userService.create(userCreateDto);
        return ResponseEntity.created(null).body(userDto);
    }

    @PutMapping("/update")
    @Override
    public ResponseEntity<UserDto> update(UserDto userDto) {
        UserDto userDtoUpdate = userService.update(userDto);

        return ResponseEntity.ok(userDtoUpdate);
    }
    @DeleteMapping("/delete/{id}")

    @Override
    public ResponseEntity<UserDto> delete(Long id) {
        UserDto userDto = userService.delete(id);
        return ResponseEntity.ok(userDto);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<UserDto>> allList(int page, int size) {
        List<UserDto> userDtos = userService.findAllByIds(page, size);
        return new ResponseEntity<>(userDtos, HttpStatus.OK);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<UserDto> findById(Long id) {
        UserDto userDto = userService.findById(id);
        return ResponseEntity.ok(userDto);
    }
}

