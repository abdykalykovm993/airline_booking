package kg.megalab.airline_booking.services;


import kg.megalab.airline_booking.models.dtos.AirportCreateDto;
import kg.megalab.airline_booking.models.dtos.AirportDto;

import java.util.List;

public interface AirportService {
    AirportDto create(AirportCreateDto airportCreateDto);

    AirportDto update(AirportDto airportDto);

    AirportDto delete(Long id);

    List<AirportDto> findAllByIds(int page, int size);

    AirportDto findById(Long id);
}
