package kg.megalab.airline_booking.controllers;

import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.PaymentCreateDto;
import kg.megalab.airline_booking.models.dtos.PaymentDto;
import kg.megalab.airline_booking.services.PaymentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/Payment")
public class PaymentController implements CRUDController<PaymentDto, PaymentCreateDto> {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }
    @PostMapping("/create")

    @Override
    public ResponseEntity<PaymentDto> create(PaymentCreateDto paymentCreateDto) {
        PaymentDto paymentDto = paymentService.create(paymentCreateDto);
        return ResponseEntity.created(null).body(paymentDto);
    }
    @PutMapping("/update")

    @Override
    public ResponseEntity<PaymentDto> update(PaymentDto paymentDto) {
        PaymentDto paymentDtoUpdate = paymentService.update(paymentDto);
        return ResponseEntity.ok(paymentDtoUpdate);
    }
    @DeleteMapping("/delete/{id}")

    @Override
    public ResponseEntity<PaymentDto> delete(Long id) {
        PaymentDto paymentDto = paymentService.delete(id);
        return ResponseEntity.ok(paymentDto);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<PaymentDto>> allList(int page, int size) {
        List<PaymentDto> paymentDtos = paymentService.findAlByIds(page, size);
        return new ResponseEntity<>(paymentDtos, HttpStatus.OK);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<PaymentDto> findById(Long id) {
        PaymentDto paymentDto = paymentService.findById(id);
        return ResponseEntity.ok(paymentDto);
    }
}
