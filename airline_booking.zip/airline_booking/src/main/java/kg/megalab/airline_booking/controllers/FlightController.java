package kg.megalab.airline_booking.controllers;

import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.FlightCreateDto;
import kg.megalab.airline_booking.models.dtos.FlightDto;
import kg.megalab.airline_booking.services.FlightService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
@RestController
@RequestMapping("/api/Flight")
public class FlightController implements CRUDController<FlightDto, FlightCreateDto> {

    private final FlightService flightService;

    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }
    @PostMapping("/create")

    @Override
    public ResponseEntity<FlightDto> create(FlightCreateDto flightCreateDto) {
        FlightDto flightDto = flightService.create(flightCreateDto);
        return ResponseEntity.created(null).body(flightDto);
    }
    @PutMapping("/update")

    @Override
    public ResponseEntity<FlightDto> update(FlightDto flightDto) {
        FlightDto flightDtoUpdate = flightService.update(flightDto);
        return ResponseEntity.ok(flightDtoUpdate);
    }
    @DeleteMapping("/delete/{id}")

    @Override
    public ResponseEntity<FlightDto> delete(Long id) {
        FlightDto flightDto = flightService.delete(id);
        return ResponseEntity.ok(flightDto);
    }

    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<FlightDto>> allList(int page, int size) {
        List<FlightDto> flightDtos = flightService.findAllByIds(page, size );
        return new ResponseEntity<>(flightDtos, HttpStatus.OK);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<FlightDto> findById(Long id) {
        FlightDto flightDto = flightService.findById(id);
        return ResponseEntity.ok(flightDto);
    }
}