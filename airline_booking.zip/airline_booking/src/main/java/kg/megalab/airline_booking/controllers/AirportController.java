package kg.megalab.airline_booking.controllers;


import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.AirportCreateDto;
import kg.megalab.airline_booking.models.dtos.AirportDto;
import kg.megalab.airline_booking.services.AirportService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Airpor")
public class AirportController implements CRUDController<AirportDto, AirportCreateDto> {

    private final AirportService airportService;

    public AirportController(AirportService airportService) {
        this.airportService = airportService;
    }
    @PostMapping("/create")

    @Override
    public ResponseEntity<AirportDto> create(AirportCreateDto airportCreateDto) {
        AirportDto airportDto = airportService.create(airportCreateDto);
        return ResponseEntity.created( null).body(airportDto);
    }
    @PutMapping("/update")

    @Override
    public ResponseEntity<AirportDto> update(AirportDto airportDto) {
        AirportDto airportDtoUpdate = airportService.update(airportDto);
        return ResponseEntity.ok(airportDtoUpdate);
    }
    @DeleteMapping("/delete/{id}")

    @Override
    public ResponseEntity<AirportDto> delete(Long id) {
        AirportDto airportDto = airportService.delete(id);
        return ResponseEntity.ok(airportDto);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<AirportDto>> allList(int page, int size) {
        List<AirportDto> airportDtos = airportService.findAllByIds(page, size);
        return new ResponseEntity<>(airportDtos, HttpStatus.OK);
    }
    @GetMapping ("/get/{id}")

    @Override
    public ResponseEntity<AirportDto> findById(Long id) {
        AirportDto airportDto =airportService.findById(id);
        return ResponseEntity.ok(airportDto);
    }
}