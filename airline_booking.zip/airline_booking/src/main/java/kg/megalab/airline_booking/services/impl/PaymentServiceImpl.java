package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;
import kg.megalab.airline_booking.mappers.PaymentMapper;
import kg.megalab.airline_booking.models.Payment;
import kg.megalab.airline_booking.models.dtos.PaymentCreateDto;
import kg.megalab.airline_booking.models.dtos.PaymentDto;
import kg.megalab.airline_booking.repository.PaymentRepo;
import kg.megalab.airline_booking.services.PaymentService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Transactional

public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepo paymentRepo;

    public PaymentServiceImpl(PaymentRepo paymentRepo) {
        this.paymentRepo = paymentRepo;
    }

    @Override
    public PaymentDto create(PaymentCreateDto paymentCreateDto) {
        Payment payment = PaymentMapper.INSTANCE.toEntity(paymentCreateDto);
        return PaymentMapper.INSTANCE.toDto(paymentRepo.save(payment)) ;
    }

    @Override
    public PaymentDto update(PaymentDto paymentDto) {
        Payment payment = PaymentMapper.INSTANCE.toEntity(paymentDto);
        return PaymentMapper.INSTANCE.toDto(paymentRepo.save(payment)) ;
    }

    @Override
    public PaymentDto delete(Long id) {
        Payment payment =paymentRepo.findById(id).orElseThrow(()-> new RuntimeException("Payment not found"));
        paymentRepo.delete(payment);
        return PaymentMapper.INSTANCE.toDto(payment);
    }

    @Override
    public List<PaymentDto> findAlByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return paymentRepo.findAllByIds(pageable);
    }

    @Override
    public PaymentDto findById(Long id) {
        Payment payment = paymentRepo.findById(id).orElseThrow(()-> new RuntimeException("Payment not found"));
        return PaymentMapper.INSTANCE.toDto(payment);
    }

}
