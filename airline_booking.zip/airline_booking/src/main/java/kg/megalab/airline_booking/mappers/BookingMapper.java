package kg.megalab.airline_booking.mappers;


import kg.megalab.airline_booking.models.Booking;
import kg.megalab.airline_booking.models.dtos.BookingCreateDto;
import kg.megalab.airline_booking.models.dtos.BookingDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BookingMapper {

    BookingMapper INSTANCE = Mappers.getMapper(BookingMapper.class);


    @Mapping(source = "user.id", target = "userId")
    @Mapping(source = "flight.id", target = "flightId")
    @Mapping(source = "seat.id", target = "seatId")

    BookingDto toDto(Booking booking);

    @Mapping(target = "user.id", source = "userId")
    @Mapping(target = "flight.id", source = "flightId")
    @Mapping(target = "seat.id", source = "seatId")
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "bookingTime", ignore = true)
    @Mapping(target = "confirmed", ignore = true)

    Booking toEntity(BookingCreateDto dto);
    @Mapping(source = "userId", target = "user.id")
    @Mapping(source = "flightId", target = "flight.id")
    @Mapping(source = "seatId", target = "seat.id")
    Booking toEntity(BookingDto bookingDto);

}
