package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;
import kg.megalab.airline_booking.mappers.FlightSegmentMapper;
import kg.megalab.airline_booking.models.FlightSegment;
import kg.megalab.airline_booking.models.dtos.FlightSegmentCreateDto;
import kg.megalab.airline_booking.models.dtos.FlightSegmentDto;
import kg.megalab.airline_booking.repository.FlightSegmentRepo;
import kg.megalab.airline_booking.services.FlightSegmentService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Transactional

public class FlightSegmentServiceImpl implements FlightSegmentService {

    private final FlightSegmentRepo flightSegmentRepo;

    public FlightSegmentServiceImpl(FlightSegmentRepo flightSegmentRepo) {
        this.flightSegmentRepo = flightSegmentRepo;
    }

    @Override
    public FlightSegmentDto create(FlightSegmentCreateDto flightSegmentCreateDto) {
        FlightSegment flightSegment = FlightSegmentMapper.INSTANCE.toEntity(flightSegmentCreateDto);
        return FlightSegmentMapper.INSTANCE.toDto(flightSegmentRepo.save(flightSegment));
    }

    @Override
    public FlightSegmentDto update(FlightSegmentDto flightSegmentDto) {
        FlightSegment flightSegment = FlightSegmentMapper.INSTANCE.toEntity(flightSegmentDto);
        return FlightSegmentMapper.INSTANCE.toDto(flightSegmentRepo.save(flightSegment));
    }

    @Override
    public FlightSegmentDto delete(Long id) {
        FlightSegment flightSegment = flightSegmentRepo.findById(id).orElseThrow(()->new RuntimeException( "Нет такого "));
        flightSegmentRepo.delete(flightSegment);
        return FlightSegmentMapper.INSTANCE.toDto(flightSegment);
    }

    @Override
    public List<FlightSegmentDto> findAllByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);

        return flightSegmentRepo.findAllByIds(pageable);
    }

    @Override
    public FlightSegmentDto findById(Long id) {
        FlightSegment flightSegment = flightSegmentRepo.findById(id).orElseThrow(()-> new RuntimeException(" нет такого "));
        return FlightSegmentMapper.INSTANCE.toDto(flightSegment);
    }
}
