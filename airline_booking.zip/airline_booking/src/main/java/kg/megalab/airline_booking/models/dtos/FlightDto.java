package kg.megalab.airline_booking.models.dtos;

import kg.megalab.airline_booking.enums.FlightStatus;

import java.time.LocalDateTime;
import java.util.List;

public record FlightDto(
        Long id,
        Long airlineId,
        Long aircraftId,
        Long fromAirportId,
        Long toAirportId,
        String flightNumber,
        LocalDateTime departureTime,
        LocalDateTime arrivalTime,
        int durationMinutes,
        FlightStatus status

) {
}
