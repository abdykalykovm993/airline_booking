package kg.megalab.airline_booking.controllers;

import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.BookingCreateDto;
import kg.megalab.airline_booking.models.dtos.BookingDto;
import kg.megalab.airline_booking.services.BookingService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Booking")
public class BookingController implements CRUDController<BookingDto, BookingCreateDto> {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }
    @PostMapping("/create")

    @Override
    public ResponseEntity<BookingDto> create(BookingCreateDto bookingCreateDto) {
        BookingDto bookingDto = bookingService.create(bookingCreateDto);
        return ResponseEntity.created(null).body(bookingDto);
    }
    @PutMapping("/update")

    @Override
    public ResponseEntity<BookingDto> update(BookingDto bookingDto) {
        BookingDto bookingDtoUpdate= bookingService.update(bookingDto);
        return ResponseEntity.ok(bookingDtoUpdate);
    }
    @DeleteMapping("/delete/{id}")

    @Override
    public ResponseEntity<BookingDto> delete(Long id) {
        BookingDto bookingDto = bookingService.delete(id);
        return ResponseEntity.ok(bookingDto);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<BookingDto>> allList(int page, int size) {
        List<BookingDto> bookingDtos = bookingService.findAllByIds(page, size);
        return new ResponseEntity<>(bookingDtos, HttpStatus.OK) ;
    }
    @GetMapping ("/get/{id}")

    @Override
    public ResponseEntity<BookingDto> findById(Long id) {
        BookingDto bookingDto = bookingService.findById(id);
        return ResponseEntity.ok(bookingDto);
    }
}
