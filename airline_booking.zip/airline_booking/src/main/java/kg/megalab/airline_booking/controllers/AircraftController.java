package kg.megalab.airline_booking.controllers;

import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.AircraftCreateDto;
import kg.megalab.airline_booking.models.dtos.AircraftDto;
import kg.megalab.airline_booking.services.AircraftService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Aircraf")
public class AircraftController implements CRUDController<AircraftDto, AircraftCreateDto> {

    private final AircraftService aircraftService;

    public AircraftController(AircraftService aircraftService) {
        this.aircraftService = aircraftService;
    }

    @PostMapping("/create")

    @Override
    public ResponseEntity<AircraftDto> create(AircraftCreateDto aircraftCreateDto) {
        AircraftDto aircraftDto = aircraftService.create(aircraftCreateDto);
        return ResponseEntity.created(null).body(aircraftDto);
    }
    @PutMapping("/update")
    @Override
    public ResponseEntity<AircraftDto> update(AircraftDto aircraftDto) {
        AircraftDto aircraftDtoUpdate = aircraftService.update(aircraftDto);
        return ResponseEntity.ok(aircraftDtoUpdate);
    }

    @DeleteMapping("/delete/{id}")
    @Override
    public ResponseEntity<AircraftDto> delete(Long id) {
        AircraftDto aircraftDto =aircraftService.delete(id);
        return ResponseEntity.ok(aircraftDto);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<AircraftDto>> allList(int page, int size) {
        List<AircraftDto> aircraftDtos = aircraftService.findAllByIds(page, size);
        return new ResponseEntity<>(aircraftDtos, HttpStatus.OK);
    }
    @GetMapping ("/get/{id}")

    @Override
    public ResponseEntity<AircraftDto> findById(Long id) {
        AircraftDto aircraftDto = aircraftService.findById(id);
        return ResponseEntity.ok(aircraftDto);
    }
}