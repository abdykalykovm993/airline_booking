package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;
import kg.megalab.airline_booking.mappers.AirportMapper;
import kg.megalab.airline_booking.models.Airport;
import kg.megalab.airline_booking.models.dtos.AirportCreateDto;
import kg.megalab.airline_booking.models.dtos.AirportDto;
import kg.megalab.airline_booking.repository.AirportRepo;
import kg.megalab.airline_booking.services.AirportService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Transactional

public class AirportServiceImpl implements AirportService {

    private final AirportRepo airportRepo;

    public AirportServiceImpl(AirportRepo airportRepo) {
        this.airportRepo = airportRepo;
    }

    @Override
    public AirportDto create(AirportCreateDto airportCreateDto) {
        Airport airport = AirportMapper.INSTANCE.toEntity(airportCreateDto);
        return AirportMapper.INSTANCE.toDto(airportRepo.save(airport));
    }

    @Override
    public AirportDto update(AirportDto airportDto) {
        Airport airport = AirportMapper.INSTANCE.toEntity(airportDto);
        return AirportMapper.INSTANCE.toDto(airportRepo.save(airport));
    }

    @Override
    public AirportDto delete(Long id) {
        Airport airport=airportRepo.findById(id).orElseThrow(()->new RuntimeException("Airport not found"));
        airportRepo.delete(airport);
        return AirportMapper.INSTANCE.toDto(airport);
    }

    @Override
    public List<AirportDto> findAllByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return airportRepo.findAllByIds(pageable);
    }

    @Override
    public AirportDto findById(Long id) {
        Airport airport = airportRepo.findById(id).orElseThrow(()->new RuntimeException("Airport not found"));
        return AirportMapper.INSTANCE.toDto(airport);
    }
}
