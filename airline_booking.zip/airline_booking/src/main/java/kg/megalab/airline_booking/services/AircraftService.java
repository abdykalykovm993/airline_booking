package kg.megalab.airline_booking.services;


import kg.megalab.airline_booking.models.dtos.AircraftCreateDto;
import kg.megalab.airline_booking.models.dtos.AircraftDto;

import java.util.List;

public interface AircraftService {
    AircraftDto create(AircraftCreateDto aircraftCreateDto);

    AircraftDto update(AircraftDto aircraftDto);

    AircraftDto delete(Long id);

    List<AircraftDto> findAllByIds(int page, int size);

    AircraftDto findById(Long id);
}
