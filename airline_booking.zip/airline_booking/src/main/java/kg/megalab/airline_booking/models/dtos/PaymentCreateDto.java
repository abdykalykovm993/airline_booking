package kg.megalab.airline_booking.models.dtos;

import kg.megalab.airline_booking.enums.PaymentStatus;

import java.time.LocalDateTime;

public record PaymentCreateDto(
        Long bookingId,
        double amount,
        String method
) {
}