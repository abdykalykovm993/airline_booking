package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;
import kg.megalab.airline_booking.mappers.AircraftTypeMapper;
import kg.megalab.airline_booking.models.AircraftType;
import kg.megalab.airline_booking.models.dtos.AircraftTypeCreateDto;
import kg.megalab.airline_booking.models.dtos.AircraftTypeDto;
import kg.megalab.airline_booking.repository.AircraftTypeRepo;
import kg.megalab.airline_booking.services.AircraftTypeService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Transactional
public class AircraftTypeServiceImpl implements AircraftTypeService {

    private final AircraftTypeRepo aircraftTypeRepo;

    public AircraftTypeServiceImpl(AircraftTypeRepo aircraftTypeRepo) {
        this.aircraftTypeRepo = aircraftTypeRepo;
    }

    @Override
    public AircraftTypeDto create(AircraftTypeCreateDto aircraftTypeCreateDto) {
        AircraftType aircraftType = AircraftTypeMapper.INSTANCE.toEntity(aircraftTypeCreateDto);
        return AircraftTypeMapper.INSTANCE.toDto(aircraftTypeRepo.save(aircraftType));
    }

    @Override
    public AircraftTypeDto update(AircraftTypeDto aircraftTypeDto) {
        AircraftType aircraftType=AircraftTypeMapper.INSTANCE.toEntity(aircraftTypeDto);
        return AircraftTypeMapper.INSTANCE.toDto(aircraftTypeRepo.save(aircraftType));
    }

    @Override
    public AircraftTypeDto delete(Long id) {
        AircraftType aircraftType = aircraftTypeRepo.findById(id).orElseThrow(()->new RuntimeException("No record found with id: " + id));
        aircraftTypeRepo.delete(aircraftType);
        return AircraftTypeMapper.INSTANCE.toDto(aircraftType);
    }

    @Override
    public List<AircraftTypeDto> findAllByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size );
        return aircraftTypeRepo.findAllByIds(pageable);
    }

    @Override
    public AircraftTypeDto findByIdDto(Long id) {
        AircraftType aircraftType = aircraftTypeRepo.findById(id).orElseThrow(()->new RuntimeException("No record found with id: " + id));
        return AircraftTypeMapper.INSTANCE.toDto(aircraftType);
    }

    @Override
    public AircraftType findById(Long type) {
        return aircraftTypeRepo.findById(type).orElseThrow(()->new RuntimeException("No record found with id: " + type));
    }
}
