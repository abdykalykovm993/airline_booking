package kg.megalab.airline_booking.mappers;

import kg.megalab.airline_booking.models.AircraftType;
import kg.megalab.airline_booking.models.dtos.AircraftTypeCreateDto;
import kg.megalab.airline_booking.models.dtos.AircraftTypeDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AircraftTypeMapper {
    AircraftTypeMapper INSTANCE = Mappers.getMapper(AircraftTypeMapper.class);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "aircraftList", ignore = true)
    AircraftType toEntity(AircraftTypeCreateDto aircraftTypeCreateDto);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "aircraftList", ignore = true)
    AircraftType toEntity(AircraftTypeDto aircraftTypeDto);

    AircraftTypeDto toDto(AircraftType aircraftType);

    }
