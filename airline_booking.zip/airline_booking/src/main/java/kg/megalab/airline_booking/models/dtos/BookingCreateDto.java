package kg.megalab.airline_booking.models.dtos;

public record BookingCreateDto(
        Long userId,
        Long flightId,
        Long seatId
) {}
