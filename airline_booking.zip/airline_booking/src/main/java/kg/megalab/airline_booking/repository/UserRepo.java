package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.User;
import kg.megalab.airline_booking.models.dtos.UserDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepo extends JpaRepository<User, Long> {

}
