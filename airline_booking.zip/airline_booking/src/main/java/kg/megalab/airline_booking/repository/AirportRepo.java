package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.Airport;
import kg.megalab.airline_booking.models.dtos.AirportDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AirportRepo extends JpaRepository<Airport, Long> {

    @Query("select new kg.megalab.airline_booking.models.dtos.AirportDto(u.id, u.name, u.city, u.country, u.iataCode) from Airport u")
    List<AirportDto> findAllByIds(Pageable pageable);
}
