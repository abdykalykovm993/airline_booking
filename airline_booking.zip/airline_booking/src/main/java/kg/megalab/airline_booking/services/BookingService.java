package kg.megalab.airline_booking.services;


import kg.megalab.airline_booking.models.dtos.BookingCreateDto;
import kg.megalab.airline_booking.models.dtos.BookingDto;

import java.util.List;

public interface BookingService {
    
    BookingDto create(BookingCreateDto bookingCreateDto);

    BookingDto update(BookingDto bookingDto);

    BookingDto delete(Long id);

    List<BookingDto> findAllByIds(int page, int size);

    BookingDto findById(Long id);
}
