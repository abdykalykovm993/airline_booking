package kg.megalab.airline_booking.models.dtos;

public record AirlineCreateDto(
        String name,
        String iataCode,
        String icaoCode,
        String country,
        String city
) {}
