package kg.megalab.airline_booking.models;

import jakarta.persistence.*;

import java.util.List;

/**
 * Тип самолета (например: Boeing 737, Airbus A320)
 */
@Entity
@Table(name = "aircraft_types")
public class AircraftType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Уникальный идентификатор типа самолета

    @OneToMany(mappedBy = "type", cascade = CascadeType.ALL)
    private List<Aircraft> aircraftList; // Список самолетов этого типа

    @Column(nullable = false)
    private String manufacturer; // Производитель (например, "Boeing")

    @Column(nullable = false)
    private String model; // Модель (например, "737")

    @Column(nullable = false, length = 3, unique = true)
    private String iataCode; // IATA-код модели (например, "738")

    public List<Aircraft> getAircraftList() {
        return aircraftList;
    }

    public void setAircraftList(List<Aircraft> aircraftList) {
        this.aircraftList = aircraftList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getIataCode() {
        return iataCode;
    }

    public void setIataCode(String iataCode) {
        this.iataCode = iataCode;
    }
}