package kg.megalab.airline_booking.models.dtos;

import kg.megalab.airline_booking.enums.SeatClass;
import kg.megalab.airline_booking.enums.SeatStatus;

public record SeatDto(
        Long id,
        Long flightId,
        Long aircraftId,
        String seatNumber,
        SeatClass seatClass,
        SeatStatus status
) {}
