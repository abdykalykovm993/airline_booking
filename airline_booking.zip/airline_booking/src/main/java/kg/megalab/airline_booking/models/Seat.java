package kg.megalab.airline_booking.models;

import jakarta.persistence.*;
import kg.megalab.airline_booking.enums.SeatClass;
import kg.megalab.airline_booking.enums.SeatStatus;

/**
 * Сиденье на борту самолета
 */
@Entity
@Table(name = "seats")
public class Seat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String seatNumber; // Номер сиденья (например, 12A)

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SeatClass seatClass; // Класс обслуживания: ECONOMY, BUSINESS

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SeatStatus status; // Статус: свободно, занято
    @ManyToOne
    private Aircraft aircraft; // Самолёт, к которому относится место
    @ManyToOne(optional = false)
    private Flight flight; // К какому рейсу относится место

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public SeatClass getSeatClass() {
        return seatClass;
    }

    public void setSeatClass(SeatClass seatClass) {
        this.seatClass = seatClass;
    }

    public SeatStatus getStatus() {
        return status;
    }

    public void setStatus(SeatStatus status) {
        this.status = status;
    }

    public Flight getFlight() {
        return flight;
    }

    public Aircraft getAircraft() {
        return aircraft;
    }

    public void setAircraft(Aircraft aircraft) {
        this.aircraft = aircraft;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;

    }
}