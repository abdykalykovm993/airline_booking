package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;
import kg.megalab.airline_booking.mappers.BookingMapper;
import kg.megalab.airline_booking.models.Booking;
import kg.megalab.airline_booking.models.dtos.BookingCreateDto;
import kg.megalab.airline_booking.models.dtos.BookingDto;
import kg.megalab.airline_booking.repository.BookingRepo;
import kg.megalab.airline_booking.services.BookingService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public class BookingServiceImpl implements BookingService {

    private final BookingRepo bookingRepo;

    public BookingServiceImpl(BookingRepo bookingRepo) {
        this.bookingRepo = bookingRepo;
    }

    @Override
    public BookingDto create(BookingCreateDto bookingCreateDto) {
        Booking booking = BookingMapper.INSTANCE.toEntity(bookingCreateDto);
        return BookingMapper.INSTANCE.toDto(bookingRepo.save(booking));
    }

    @Override
    public BookingDto update(BookingDto bookingDto) {
        Booking booking = BookingMapper.INSTANCE.toEntity(bookingDto);
        return BookingMapper.INSTANCE.toDto(bookingRepo.save(booking));
    }

    @Override
    public BookingDto delete(Long id) {
         Booking booking = bookingRepo.findById(id).orElseThrow(()-> new RuntimeException("Booking not found"));
         bookingRepo.delete(booking);
         return BookingMapper.INSTANCE.toDto(booking);
    }

    @Override
    public List<BookingDto> findAllByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return bookingRepo.findAllByIds(pageable).getContent();
    }



    @Override
    public BookingDto findById(Long id) {
        Booking booking = bookingRepo.findById(id).orElseThrow(()-> new RuntimeException("Booking not found"));
        return BookingMapper.INSTANCE.toDto(booking);
    }
}
