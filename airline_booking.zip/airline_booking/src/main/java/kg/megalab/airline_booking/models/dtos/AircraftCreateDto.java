package kg.megalab.airline_booking.models.dtos;

public record AircraftCreateDto(
        String registrationNumber,
        Long airlineId,
        Long aircraftTypeId

) {
}
