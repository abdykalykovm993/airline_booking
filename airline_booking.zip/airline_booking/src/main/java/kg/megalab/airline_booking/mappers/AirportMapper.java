package kg.megalab.airline_booking.mappers;

import kg.megalab.airline_booking.models.Airport;
import kg.megalab.airline_booking.models.dtos.AirportCreateDto;
import kg.megalab.airline_booking.models.dtos.AirportDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AirportMapper {

    AirportMapper INSTANCE = Mappers.getMapper(AirportMapper.class);
    @Mapping(target = "id", ignore = true)

    Airport toEntity(AirportCreateDto airportCreateDto);

    AirportDto toDto(Airport save);

    Airport toEntity(AirportDto airportDto);
}
