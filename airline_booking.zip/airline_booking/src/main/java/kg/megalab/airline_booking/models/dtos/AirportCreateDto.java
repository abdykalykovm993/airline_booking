package kg.megalab.airline_booking.models.dtos;

public record AirportCreateDto(
        String iataCode,
        String name,
        String city,
        String country
) {}
