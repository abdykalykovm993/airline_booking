package kg.megalab.airline_booking.models;


import jakarta.persistence.*;


@Entity
@Table(name = "aircrafts")
public class Aircraft {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Уникальный ID самолета

    @Column(nullable = false, unique = true)
    private String registrationNumber; // Регистрационный номер (например, "EX-123")
    @JoinColumn
    @ManyToOne(optional = false)
    private Airline airline; // Авиакомпания, владеющая самолетом
    @JoinColumn
    @ManyToOne(optional = false)
    private AircraftType type; // Тип самолета (Boeing 737 и т.д.)

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public Airline getAirline() {
        return airline;
    }

    public void setAirline(Airline airline) {
        this.airline = airline;
    }

    public AircraftType getType() {
        return type;
    }

    public void setType(AircraftType type) {
        this.type = type;
    }
}