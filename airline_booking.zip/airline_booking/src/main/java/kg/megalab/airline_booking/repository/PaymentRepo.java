package kg.megalab.airline_booking.repository;

import kg.megalab.airline_booking.models.Payment;
import kg.megalab.airline_booking.models.dtos.PaymentDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaymentRepo extends JpaRepository<Payment, Long> {

    @Query("select new kg.megalab.airline_booking.models.dtos.PaymentDto(u.id, u.booking.id, u.amount, u.method, u.paymentTime, u.status) from Payment u")
    List<PaymentDto> findAllByIds(Pageable pageable);
}
