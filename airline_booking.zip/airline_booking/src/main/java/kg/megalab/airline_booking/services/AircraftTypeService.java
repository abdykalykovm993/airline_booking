package kg.megalab.airline_booking.services;


import kg.megalab.airline_booking.models.AircraftType;
import kg.megalab.airline_booking.models.dtos.AircraftTypeCreateDto;
import kg.megalab.airline_booking.models.dtos.AircraftTypeDto;

import java.util.List;

public interface AircraftTypeService {
    AircraftTypeDto create(AircraftTypeCreateDto aircraftTypeCreateDto);

    AircraftTypeDto update(AircraftTypeDto aircraftTypeDto);

    AircraftTypeDto delete(Long id);

    List<AircraftTypeDto> findAllByIds(int page, int size);

    AircraftTypeDto findByIdDto(Long id);

    AircraftType findById(Long type);
}
