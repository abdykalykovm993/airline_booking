package kg.megalab.airline_booking.controllers;


import kg.megalab.airline_booking.controllers.cruds.CRUDController;
import kg.megalab.airline_booking.models.dtos.AirlineCreateDto;
import kg.megalab.airline_booking.models.dtos.AirlineDto;
import kg.megalab.airline_booking.services.AirlineService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/Airline")
public class AirlineController implements CRUDController<AirlineDto, AirlineCreateDto> {

    private final AirlineService airlineService;

    public AirlineController(AirlineService airlineService) {
        this.airlineService = airlineService;
    }
    @PostMapping("/create")

    @Override
    public ResponseEntity<AirlineDto> create(AirlineCreateDto airlineCreateDto) {
        AirlineDto airlineDto = airlineService.create(airlineCreateDto);
        return ResponseEntity.created(null).body(airlineDto);
    }
@PutMapping("/update")
    @Override
    public ResponseEntity<AirlineDto> update(AirlineDto airlineDto) {
        AirlineDto airlineDtoUpdate = airlineService.update(airlineDto);
        return ResponseEntity.ok(airlineDtoUpdate);
    }
    @DeleteMapping("/delete/{id}")

    @Override
    public ResponseEntity<AirlineDto> delete(Long id) {
        AirlineDto airlineDto = airlineService.delete(id);
        return ResponseEntity.ok(airlineDto);
    }
    @GetMapping ("/get/all")

    @Override
    public ResponseEntity<List<AirlineDto>> allList(int page, int size) {
        List<AirlineDto> airlineDtos = airlineService.findAllByIds(page, size);
        return new ResponseEntity<>(airlineDtos, HttpStatus.OK);
    }
    @GetMapping ("/get/{id}")

    @Override
    public ResponseEntity<AirlineDto> findById(Long id) {
        AirlineDto airlineDto = airlineService.findByIdDto(id);
        return ResponseEntity.ok(airlineDto);
    }


}
