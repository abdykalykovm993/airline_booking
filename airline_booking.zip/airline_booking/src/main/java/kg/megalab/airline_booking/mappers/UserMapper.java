package kg.megalab.airline_booking.mappers;


import kg.megalab.airline_booking.models.User;
import kg.megalab.airline_booking.models.dtos.UserCreateDto;
import kg.megalab.airline_booking.models.dtos.UserDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UserMapper {

    UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);
    @Mapping(target = "id", ignore = true)

    User toEntity(UserCreateDto userCreateDto);

    User toEntity(UserDto userDto);

    UserDto toDto(User save);
}
