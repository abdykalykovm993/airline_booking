package kg.megalab.airline_booking.mappers;

import kg.megalab.airline_booking.models.Aircraft;
import kg.megalab.airline_booking.models.AircraftType;
import kg.megalab.airline_booking.models.Airline;
import kg.megalab.airline_booking.models.dtos.AircraftCreateDto;
import kg.megalab.airline_booking.models.dtos.AircraftDto;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AircraftMapper {
    AircraftMapper INSTANCE = Mappers.getMapper(AircraftMapper.class);

    @Mapping(source = "airlineId", target = "airline")
    @Mapping(source = "aircraftTypeId", target = "type")
    @Mapping(target = "id", ignore = true)
    Aircraft toEntity(AircraftCreateDto dto);

    @Mapping(source = "airlineId", target = "airline")
    @Mapping(source = "aircraftTypeId", target = "type")
    @Mapping(target = "id", ignore = true)
    Aircraft toEntity(AircraftDto dto);

    @Mapping(source = "airline.id", target = "airlineId")
    @Mapping(source = "type.id", target = "aircraftTypeId")
    AircraftDto toDto(Aircraft entity);

    default Airline map(Long id) {
        if (id == null) return null;
        Airline airline = new Airline();
        airline.setId(id);
        return airline;
    }

    default AircraftType mapType(Long id) {
        if (id == null) return null;
        AircraftType type = new AircraftType();
        type.setId(id);
        return type;
    }
}
