package kg.megalab.airline_booking.services.impl;

import jakarta.transaction.Transactional;

import kg.megalab.airline_booking.mappers.AirlineMapper;
import kg.megalab.airline_booking.models.Airline;
import kg.megalab.airline_booking.models.dtos.AirlineCreateDto;
import kg.megalab.airline_booking.models.dtos.AirlineDto;
import kg.megalab.airline_booking.repository.AirlineRepo;
import kg.megalab.airline_booking.services.AirlineService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional

public class AirlineServiceImpl implements AirlineService {

    private final AirlineRepo airlineRepo;

    public AirlineServiceImpl(AirlineRepo airlineRepo) {
        this.airlineRepo = airlineRepo;
    }

    @Override
    public AirlineDto create(AirlineCreateDto airlineCreateDto) {
        Airline airline = AirlineMapper.INSTANCE.toEntity(airlineCreateDto);
        return AirlineMapper.INSTANCE.toDto(airlineRepo.save(airline));
    }

    @Override
    public AirlineDto update(AirlineDto airlineDto) {
        Airline airline = AirlineMapper.INSTANCE.toEntity(airlineDto);
        return AirlineMapper.INSTANCE.toDto(airlineRepo.save(airline));
    }

    @Override
    public AirlineDto delete(Long id) {
        Airline airline = airlineRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Airline not found"));
        airlineRepo.delete(airline);
        return AirlineMapper.INSTANCE.toDto(airline);
    }

    @Override
    public List<AirlineDto> findAllByIds(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return airlineRepo.findAllByIds(pageable);
    }

    @Override
    public AirlineDto findByIdDto(Long id) {
        Airline airline = airlineRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Airline not found"));
        return AirlineMapper.INSTANCE.toDto(airline);
    }

    @Override
    public Airline findById(Long aLong) {
        return airlineRepo.findById(aLong)
                .orElseThrow(() -> new IllegalArgumentException("Airline not found"));
    }

}
