package kg.megalab.airline_booking.models.dtos;

public record AircraftDto(
        Long id,
        Long airlineId,
        Long aircraftTypeId,
        String registrationNumber


) {
}